package psa.naloga0;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.BitSet;

import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;




public class Naloga {


	boolean[] podatki;
	String hashName = "MD5";
	final MessageDigest digestFunc;
	int k;
	int velikost;





	public Naloga(int velikost, int k) {
		 MessageDigest tmp;
		 try {
		     tmp = java.security.MessageDigest.getInstance(hashName);
		 } catch (NoSuchAlgorithmException e) {
		     tmp = null;
		 }
		 digestFunc = tmp;

		this.podatki = new boolean[velikost];
		this.k = k;
		this.velikost = velikost;




	}

	public void clear() {
		this.podatki = new boolean[velikost];
	}

	/**
	 * @param input
	 */
	public void add(String input) {
		// vzet element
		//  zakodirat
		// na vsakem mestu dat v true na polju

		byte[] biti =  input.getBytes();

		int[] koda = createHashes(biti, this.k);

		for (int i = 0; i < koda.length; i++) {
			// predpostaviš da ti createHashes funkicja da znotraj polja odgovore
			this.podatki[koda[i]] = true;
		}

	}

	public boolean contains(String input) {

		// vez element
		// zakodirava
		// PREVERVA ali so VSI TRUE -> je LAHKO not
		byte[] biti =  input.getBytes();

		int[] koda = createHashes(biti, this.k);
		boolean fin = true;

		for (int i = 0; i < koda.length; i++) {
			// predpostaviš da ti createHashes funkicja da znotraj polja odgovore
			if (this.podatki[koda[i]] == true ){
				continue;
			}
			fin = false;
		}

		return fin;

	}


	
	public int[] createHashes(byte[] data, int hashes) {
        int[] result = new int[hashes];

        int k = 0;
        while (k < hashes) {
            byte[] digest;
            digest = digestFunc.digest(data);
        
            for (int i = 0, j = 0; i < digest.length && k < hashes; i+=2, j++) {
                result[j] = Math.abs(((int)digest[i] << 8) | ((int)digest[i+1] & 0xFF))%velikost;
                k++;
            }
        }
        return result;
    }






}
