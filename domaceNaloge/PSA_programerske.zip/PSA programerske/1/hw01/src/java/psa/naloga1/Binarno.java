package psa.naloga1;

public class Binarno {
	private NodeBinarno root;

	Binarno() {
		this.root = null;
	}

	public boolean insert(int element) {
		if(root == null) {
			root = new NodeBinarno(element);
			return true;
		}

		NodeBinarno node = new NodeBinarno(element);
		int cmps = root.compare(node);

		if (cmps == 0) return false;

		else if (cmps < 0) {
			if (root.getLeft() == null) {
				root.setLeft(node);
				return true;
			}
			else return root.getLeft().insert(node);
		}

		else {
			if (root.getRight() == null) {
				root.setRight(node);
				return true;
			}
			else return root.getRight().insert(node);
		}
	}

	public boolean delete(int element) {
		if(root == null) return false;

		NodeBinarno node = new NodeBinarno(element);
		int cmps = root.compare(node);

		if (cmps == 0) {
			if (root.getLeft() == null && root.getRight() == null) {
				root = null;
			}

			else if (root.getLeft() == null) {
				root = root.getRight();
			}

			else if (root.getRight() == null) {
				root = root.getLeft();
			}

			else {
				if(root.getRight().getLeft() == null) {
					root.getRight().setLeft(root.getLeft());
					root = root.getRight();
				}
				else {
					NodeBinarno minParent = root.getRight().findMin();
					root.setKey(minParent.getLeft().getKey());
					minParent.setLeft(null);
				}
			}
			return true;
		}

		else return root.delete(node);
	}

	public boolean search(int element) {
		if (this.root == null) return false;

		NodeBinarno node = new NodeBinarno(element);
		int cmps = root.compare(node);

		if (cmps == 0)  return true;

		else if(cmps < 0) {
			if(root.getLeft() == null) return false;
			else return root.getLeft().search(node);
			}
		else {
			if(root.getRight() == null) return false;
			else return root.getRight().search(node);
		}
	}

	public int getCounter() {
		return root != null?root.getCounter():null;
	}
	
	public void resetCounter() {
		if(root!= null)
			root.resetCounter();
	}
}

