package psa.naloga3;

import java.util.Random;

public class SkipList {

	private NodeSkipList sentinel;
	private long maxNodes;
	private int height;

	public SkipList(long maxNodes) {
		this.maxNodes = maxNodes;
		height = (int) Math.ceil(Math.log((int) maxNodes) / Math.log(2));
		sentinel = new NodeSkipList(Integer.MIN_VALUE, height);

	}

	public long coin() {
		boolean tail = false;
		long height = 0;
		while(!tail) {
			Random random = new Random();
			int chance = random.nextInt(2);
			tail = chance == 1;
			height++;
		}
		return height % this.height;
	}


	public boolean insert(int searchKey) {
		if(maxNodes == 0) return false;

		NodeSkipList pointer = sentinel;
		int level = height - 1;
		NodeSkipList[] predecessors = new NodeSkipList[height];
		while (level >= 0) {
			while (pointer.next[level] != null && pointer.next[level].key < searchKey)
				pointer = pointer.next[level];
			if (pointer.next[level] != null && pointer.next[level].key == searchKey) return false;
			predecessors[level--] = pointer;
		}

		NodeSkipList node = new NodeSkipList(searchKey, coin());
		for (int i = 0; i < node.next.length; i++) {
			node.next[i] = predecessors[i].next[i];
			predecessors[i].next[i] = node;
		}
		maxNodes--;
		return true;
	}


	public boolean search(int searchKey) {
		if (sentinel == null) return false;

		else {
			NodeSkipList pointer = sentinel;
			int level = height - 1;
			while(level >= 0) {
				while(pointer.next[level] != null && pointer.next[level].key < searchKey) pointer = pointer.next[level];
				level--;
			}
			return pointer.next[0] != null && pointer.next[0].key == searchKey;
		}
	}


	public boolean delete(int key) {
		boolean removed = false;
		NodeSkipList pointer = sentinel;
		int level = height - 1;

		while(level >= 0) {
			while(pointer.next[level] != null && pointer.next[level].key < key) pointer = pointer.next[level];

			if(pointer.next[level] != null && pointer.next[level].key == key) {
				pointer.next[level] = pointer.next[level].next[level];
				removed = true;
			}
			level--;
		}
		if (removed) maxNodes++;
		return removed;
	}

	public void printSkipList() {
		for (int i = height - 1; i >= 0; i--) {
			if(sentinel.next[i] == null) {
				System.out.println(i + " -> Null");
			}
			else {
				NodeSkipList list = sentinel.next[i];
				System.out.print(i + " -> ");
				while (list != null) {
					System.out.print(list.key + " -- ");
					list = list.next[i];
				}
				System.out.print(" Null ");
				System.out.println();
			}
		}
	}
}
