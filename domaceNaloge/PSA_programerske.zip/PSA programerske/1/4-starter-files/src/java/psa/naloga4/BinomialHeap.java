package psa.naloga4;

import java.util.Random;

public class BinomialHeap {
	BinomialNode[] data;
	
	BinomialHeap(){
		data = new BinomialNode[1];
		//System.out.println(data[0]);
	} //crate empty array
	
	public boolean insert(int key) {
		//System.out.println("---insert of " + key + " -----------");
		//this.printHeap();
		if(data[0] == null) {
			data[0] = new BinomialNode(key);
			return true;
		}
		//find last filled slot
		else {
			BinomialNode newNode = new BinomialNode(key);
			int index = 0;
			while(data[index] != null) {
				if (index == data.length - 1) resizeArray();
				newNode = merge(newNode, data[index]);
				data[index++] = null;
			}
			data[index] = newNode;
			return true;
		}
	}
	
	public int getMin() {
		int min = Integer.MAX_VALUE;
		for(int i = 0; i < data.length; i++) {
			//System.out.println("looking at " + i);
			if (data[i] != null && data[i].getKey() < min) min = data[i].getKey();
		}
		return min;
	}
	
	public boolean delMin() {
		int min = this.getMin();
		if (min == Integer.MAX_VALUE) return false;
		int i = 0;

		while(true){
			if (data[i] != null && data[i].getKey() == min) {
				if(i == 0) data[i] = null;

				else{
					BinomialNode[] children = new BinomialNode[i];
					for(int k = 0; k < i; k++) {
						children[k] = data[i].getChildren().elementAt(k);
					}
					data[i] = null;

					for(int p = children.length - 1; p >= 0; p--) {
						int q = p;
						BinomialNode node = children[p];
						while(data[q] != null) {
							node = merge(node, data[q]);
							data[q++] = null;
						}
						data[q] = node;
					}
				}
				return true;
			}
			else i++;
		}
	}
	
	private void resizeArray() {
		//System.out.println("\nresizing");
		BinomialNode[] newData = new BinomialNode[data.length * 2];
		for(int i = 0; i < data.length; i++) {
			newData[i] = data[i];
		}
		data = newData;
		//this.printHeap();
	}

	
	private BinomialNode merge(BinomialNode t1, BinomialNode t2) {
		if (t1 == null) return t2;
		else if (t2 == null) return t1;
		else {
				if (t1.getKey() < t2.getKey()) {
					t1.addChild(t2);
					return t1;
				} else {
					t2.addChild(t1);
					return t2;
				}
			}
	}


	public void printHeap() {
		int index = 0;
		while(index < data.length) {
			if(data[index] == null) System.out.print(" -/- ");
			else
				data[index].printNode();
			System.out.println("\n----");
			index++;
		}
		System.out.println("end of print ----\n\n\n");
	}

	public void generate() {
		Random rand = new Random();
		for (int i = 0; i < 20; i++) {
			int e = rand.nextInt(-90, 150);
			//System.out.println("adding " + e);
			this.insert(e);
		}
	}
}


