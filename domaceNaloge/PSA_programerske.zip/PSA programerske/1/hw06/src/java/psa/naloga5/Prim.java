package psa.naloga5;

import java.util.HashSet;
import java.util.Vector;

public class Prim {
	int[][] data;
	int n;

	public Prim(int n) {
		data = new int[n][n];
		this.n = n;
	}

	public Prim(int[][] d) {
		data = d;
		n = d.length;
	}

	public void addEdge(int i, int j, int d) {
		data[i][j] = d;
		data[j][i] = d;
	}

	public int MSTcost() {
		int[] mst = prim(0);
		int cost = 0;
		for (int i = 0; i < mst.length; i++) {
			cost += data[i][mst[i]];
		}
		return cost;
	}

	public int[] prim(int s) {
		int[] parent = new int[n];

		//setting distances to infinity
		//empty set for included vertices
		int[] weight = new int[n]; //distances
		boolean[] mst = new boolean[n];
		for(int i = 0; i < n; i++) {
			weight[i] = Integer.MAX_VALUE;
			mst[i] = false;
		}

		//adding source
		weight[s] = 0;
		parent[s] = 0;

		//until we have all the vertices
		int counter = 0;
		while(counter < n - 1) {
			int u = minKey(weight, mst);
			mst[u] = true;

			for(int v = 0; v < n; v++) {
				if(!mst[v] && data[u][v] != 0 && data[u][v] < weight[v]) {
					weight[v] = data[u][v];
					parent[v] = u;
				}
			}
			counter++;
		}
		return parent;
	}

	int minKey(int[] key, boolean[] included)
	{
		// Initializing min value
		int min = Integer.MAX_VALUE, min_index = -1;

		for (int v = 0; v < n; v++)
			if (!included[v] && key[v] < min) {
				min = key[v];
				min_index = v;
			}

		return min_index;
	}
}
