package psa.naloga4;

import java.util.Vector;

public class BinomialHeap {
	BinomialNode[] data;
	
	BinomialHeap(){
		data = new BinomialNode[1];
		//System.out.println(data[0]);
	} //crate empty array
	
	public boolean insert(int key) {
		//System.out.println("---insert of " + key + " -----------");
		//this.printHeap();
		if(data[0] == null) {
			data[0] = new BinomialNode(key);
			return true;
		}
		//find last filled slot
		else {
			int index = 0;
			while(index < data.length && data[index] != null) index++; //if full, it will break when index = data.length
			//System.out.println("index turned out to be " + index);
			if (index == data.length) resizeArray();
			//System.out.println("about to insert it position " + index);
			data[index] = new BinomialNode(key);
			//this.printHeap();
			cleanUp(this);

			return true;
		}
	}
	
	public int getMin() {
		if(data[0] == null) return Integer.MAX_VALUE;
		int minIndex = 0;
		for(int i = 0; i < data.length; i++) {
			//System.out.println("looking at " + i);
			if (data[i] != null && (data[i].getKey() < data[minIndex].getKey())) minIndex = i;
		}
		return data[minIndex].getKey();
	}
	
	public boolean delMin() {
		if(data[0] == null) return false;
		int minIndex = 0;
		for(int i = 0; i < data.length; i++) {
			//System.out.println("looking at " + i);
			if (data[i] != null && (data[i].getKey() < data[minIndex].getKey())) minIndex = i;
		}
		//deleting children
		System.out.println("deleting " + data[minIndex].getKey());
		BinomialNode deleting = data[minIndex];
		data[minIndex] = null;
		//shifting trees so no empty slot between
		while(data[minIndex + 1] != null) {
			data[minIndex] = data[minIndex + 1];
			data[minIndex + 1] = null;
			minIndex++;
		}
		System.out.println("after shift: ");
		this.printHeap();
		//deleting.printNode();

		//making heap out of orphans
		//should add in reverse order since Vector behaves like stack
		BinomialHeap orphans = new BinomialHeap();
		int size = deleting.getChildren().size();
		//System.out.println(size);
		orphans.data = new BinomialNode[size];
		for(int k = 0; k < size; k++) {
			orphans.data[k] = deleting.getChildren().elementAt(size - 1 - k);
		}
		System.out.println("orphans: ");
		orphans.printHeap();
		this.data = mergeHeap(orphans, this);


		return true;
	}
	
	private void resizeArray() {
		//System.out.println("\nresizing");
		BinomialNode[] newData = new BinomialNode[data.length * 2];
		for(int i = 0; i < data.length; i++) {
			newData[i] = data[i];
		}
		data = newData;
		//this.printHeap();
	}
	
	private BinomialNode merge(BinomialNode t1, BinomialNode t2) {
		if(t1.getKey() < t2.getKey()) {
			t1.addChild(t2);
			return t1;
		}
		else {
			t2.addChild(t1);
			return t2;
		}
	}
	//maybe no need for h1 and h2 distinction
	private BinomialNode[] mergeHeap(BinomialHeap h1, BinomialHeap h2) {
		BinomialHeap  result = new BinomialHeap();

		int len1 = h1.data.length;
		int len2 = h2.data.length;

		int len = 1;
		while (len < len1 + len2) len *= 2;
		result.data = new BinomialNode[len];

		//smaller index, bigger tree
		int ind1 = 0, ind2 = 0, r = 0;
		while (ind1 < len1 && h1.data[ind1] != null && ind2 < len2 && h2.data[ind2] != null) {
			if (h1.data[ind1].getChildren().size() >= h2.data[ind2].getChildren().size()) {
				result.data[r++] = h1.data[ind1++];
			} else {
				result.data[r++] = h2.data[ind2++];
			}
		}
		if(ind1 < len1) while(ind1 < len1 && h1.data[ind1] != null) result.data[r++] = h1.data[ind1++];
		if(ind2 < len2) while (ind2 < len2 && h2.data[ind2] != null) result.data[r++] = h2.data[ind2++];
		result.printHeap();
		cleanUp(result);

		return result.data;
	}

	private void cleanUp(BinomialHeap h) {
		int full = h.data.length - 1;
		while(h.data[full] == null) full--;
		//combining same size trees
		//System.out.println("\nat the start: "+ full);
		for (int i = full; i > 0; i--) {
			//System.out.println("curr at: " + i);
			//System.out.println("about to compare: " + h.data[i - 1].getChildren().size() + " and: " + h.data[i].getChildren().size());
			if (h.data[i - 1].getChildren().size() == h.data[i].getChildren().size()) {
				h.data[i - 1] = merge(h.data[i - 1], h.data[i]);
				h.data[i] = null;
			}
		}
	}

	public void printHeap() {
		int index = 0;
		while(index < data.length) {
			if(data[index] == null) System.out.print(" -/- ");
			else
				data[index].printNode();
			System.out.println("\n----");
			index++;
		}
		System.out.println("\n\n\nend of print ----");
	}
}

