package psa.naloga3;

import junit.framework.TestCase;

/**
 * insert Public Tests to this class. Public tests are written by the Instructor
 * and may be used for grading projects. This source code is made available to
 * students.
 */
public class PublicTests extends TestCase {

	private HashTable ht;
	private HashTable2 ht2;
	private String text = "1 2 4 45 23 3 6 34 25 8 12 10 -21 -43 -22 100 105 -99 -67 "; //13 99 -18 10453 19532 -2981 -21374 -91238 21341";
		
	protected void setUp() throws Exception {
		ht = new HashTable();
		ht2 = new HashTable2();
	}
	
	public void testInsertHashTable2() {
		ht2.insert(1);
		assertTrue(ht2.data[53] == 1);
		ht2.printTable();
		ht2.insert(1);
		ht2.printTable();
	}
	
	public void testSearchHashTable2Success() {
		ht2.insert(10);
		ht2.printTable();
		ht2.insert(10);
		ht2.insert(15);
		for (String i:text.split(" ")){
			ht2.insert(Integer.parseInt(i));
		}
		ht2.printTable();
		//assertTrue(ht2.search(10));
		//assertTrue(ht2.search(15));
		//assertTrue(ht2.search(105));
		//assertTrue(ht2.search(-22));
		assertTrue(ht2.delete(-22));
		ht2.printTable();
		System.out.println(ht2.search(-22));
		//assertTrue(ht2.search(-21));

	}
	
	public void testSearchHashTable2Fail() {
		//assertFalse(ht2.search(15));
		ht2.insert(10);
		//assertFalse(ht2.search(17));
		int[] array = {1, 2, 3, 4, 6, 7, 8, 13, 10, 11, 12, 89, 14, 15, 16};
		HashTable2 ht22 = new HashTable2();
		ht22.setData(array);
		ht22.printTable();
		assertFalse(ht22.search(9));
		assertTrue(ht22.delete(89));
		assertTrue(ht22.delete(15));
		assertTrue(ht22.delete(14));
		ht22.printTable();
		assertFalse(ht22.delete(14));
		assertFalse(ht22.search(147));
	}
	
	public void testVnosZeObstojecegaHasthTable2() {
		ht.insert(201);
		assertFalse(ht.insert(201));
	}

	public void testInsert() {
		ht.insert(0);
		assertTrue(ht.data[0].data[0] == 0);
	}
	
	public void testVnosZeObstojecega() {
		ht.insert(2);
		assertFalse(ht.insert(2));
	}
}
