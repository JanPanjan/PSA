package psa.naloga3;

/*
 * Razred mora imeplementirati podatkovno strukturo Razprsilne tabele.
 * Za funkcijo uporabite: h(x) = x * 53 mod size
 * V primeru kolizij uporabite LINEARNO NASLAVLJANJE.
 */
public class HashTable2 {

	public int[] data;
	int[] isDeleted;
	int[] isInserted;
	int size = 15;

	HashTable2() {
		data = new int[size];
		isDeleted = new int[size];
		isInserted = new int[size];
	}

	public void setData(int[] array) {
		if (array.length == size) {
			this.data = array;
			for(int i = 0; i < size; i++) {this.isInserted[i] = 1;
				System.out.println(isInserted[i]);
			}
		}
	}

	public int hash(int k) {
		return Math.floorMod((k * 53), size);
	}

	/*
	 * Metoda sprejme število in ga vstavi v tabelo. Metoda vrne true, ce je
	 * bilo ustavljanje uspešno in false sicer
	 */
	public boolean insert(int key) {
		System.out.println("insert of " + key);
		if(this.search(key)) return false;
		int i = hash(key);
		System.out.println(i);
		int end = (i == 0) ? (size - 1) : i - 1;
		while(i != end && isInserted[i] == 1) {
			//System.out.println("in insert while, just checked isInserted for i = " + i);
			i = (i == size - 1) ? 0 : i + 1;
		}
		//System.out.println("i I got is: " + i);
		if(isInserted[i] == 1) {
			System.out.println("table full\n\n");
			return false; //table is full
		}

		data[i] = key;
		isInserted[i] = 1;
		isDeleted[i] = 0;
		//System.out.println("isInserted: ");
		//System.out.println(isInserted);
		return true;
	}

	/*
	 * Metoda sprejme število in ga poišče v tabeli. Metoda vrne true, ce je
	 * bilo ustavljanje uspešno in false sicer
	 */
	public boolean search(int key) {
		System.out.println("\n----search for " + key + " -----");
		printTable();
		int i = hash(key);
		System.out.println("first index i look at is: " + i);
		int end = (i == 0) ? size - 1 : i - 1;
		System.out.println("will be checking until index " + end);
		while(i != end && (isInserted[i] == 1 || isDeleted[i] == 1)) {
			System.out.println("=> at i " + i + " with data " + data[i]);
			if(data[i] == key) return isDeleted[i] != 1;
			i = (i == size - 1) ? 0 : i + 1;
		}
		System.out.println("got i as " + i + " and end at " + end);
		//still have to check for (end)th index
		return data[end] == key && isDeleted[end] == 0;
	}

	/*
	 * Metoda sprejme število in ga izbriše iz tabele. Metoda vrne true, ce je
	 * bilo ustavljanje uspešno in false sicer
	 */
	public boolean delete(int key) {
		System.out.println("---- deleting " + key + " ------------");
		int i = hash(key);
		int end = i;
		do {
			System.out.println("starting the do with i: " + i);
			if(data[i] == key) {
				if(isInserted[i] == 1 && isDeleted[i] == 0) {
					isInserted[i] = 0;
					isDeleted[i] = 1;
					return true;
				}
				else return false;
			}
			i = (i == size - 1) ? 0 : i + 1;
		} while(i != end && (isInserted[i] == 1 || isDeleted[i] == 1));

		return false;
	}

	public void printTable() {
		for(int i = 0; i < size; i++) {
			System.out.println(i + " -> " + (isInserted[i] == 1 ? data[i] : "null") + " [" + isInserted[i] + ", " + isDeleted[i] + "]");
		}
	}
}
