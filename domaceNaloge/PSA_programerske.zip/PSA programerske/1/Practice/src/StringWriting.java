import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

//Exam 1 20/21, task  4
public class StringWriting {

    public static void main(String[] args) {
        CyclicBarrier barrier = new CyclicBarrier(2);
        PrintThread thread1 = new PrintThread(barrier);
        PrintThread thread2 = new PrintThread(barrier);
        Print print = new Print("FAMNIT");

        thread1.start();
        thread2.start();

        try{
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {}

    }


}

class PrintThread extends Thread {
    CyclicBarrier barrier;

    public PrintThread(CyclicBarrier barrier) {this.barrier = barrier;}

    @Override
     public void run() {
        int len = Print.string.length();
        for (int i = len - 1; i >= 0; i--) {
            if (i == 0) System.out.print(Print.string.charAt(i));
            else System.out.print(Print.string.charAt(i) + " - ");
            try{
                this.barrier.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}


class Print {
    public static String string;

    public Print(String string) {
        this.string = string;
    }
}
