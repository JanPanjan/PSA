public class reverseFamnit implements Runnable {

    String value;
    reverseFamnit(String value){
        this.value=value;
    }

    public void run() {
        for(int i=value.length()-1;i>=0;i--) {
            System.out.print(value.charAt(i)+"-");
            try {
                Thread.sleep(1000);
            }catch(InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    public static void main(String[]args) throws InterruptedException {
        reverseFamnit f =new reverseFamnit("FAMNIT");

        Thread t1=new Thread(f);
        Thread t2=new Thread(f);
        t1.start();
        t2.start();
    }}